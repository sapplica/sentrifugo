CREATE TABLE `main_requisition_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `requisition_id` int(20) DEFAULT NULL,
  `candidate_id` int(20) DEFAULT NULL,
  `candidate_name` varchar(150) DEFAULT NULL,
  `interview_id` int(20) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `createdby` int(11) DEFAULT NULL,
  `modifiedby` int(11) DEFAULT NULL,
  `createddate` datetime DEFAULT NULL,
  `modifieddate` datetime DEFAULT NULL,
  `isactive` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main_leaverequest_history` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `leaverequest_id` INT(20) DEFAULT NULL,
  `description` VARCHAR(500) DEFAULT NULL,
  `createdby` INT(11) DEFAULT NULL,
  `modifiedby` INT(11) DEFAULT NULL,
  `createddate` DATETIME DEFAULT NULL,
  `modifieddate` DATETIME DEFAULT NULL,
  `isactive` TINYINT(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `main_vendors` (			
		`id` int(11) unsigned NOT NULL AUTO_INCREMENT,			
		`name` varchar(255) DEFAULT NULL,			
		`contact_person` varchar(255) DEFAULT NULL,			
		`address` varchar(200) DEFAULT NULL,			
		`country` bigint(20) DEFAULT NULL,			
		`state` bigint(20) DEFAULT NULL,			
		`city` bigint(20) DEFAULT NULL,			
		`pincode` varchar(15) DEFAULT NULL,			
		`primary_phone` varchar(15) DEFAULT NULL,			
		`secondary_phone` varchar(15) DEFAULT NULL,			
		`createdby` int(10) unsigned DEFAULT NULL,			
		`modifiedby` int(10) unsigned DEFAULT NULL,			
		`createddate` datetime DEFAULT NULL,			
		`modifieddate` datetime DEFAULT NULL,			
		`isactive` tinyint(1) DEFAULT '1',			
		PRIMARY KEY (`id`)			
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

ALTER TABLE `main_candidatedetails` ADD COLUMN  `source` ENUM('Vendor','Website','Referal')  AFTER `pincode`;
ALTER TABLE `main_candidatedetails` ADD COLUMN `source_val` VARCHAR(150) AFTER `source`;
ALTER TABLE `main_candidatedetails` DROP INDEX `NewIndex1`;
ALTER TABLE `main_candidatedetails` DROP INDEX `NewIndex2`;
ALTER TABLE `main_requisition` ADD COLUMN `recruiters` int(11) AFTER `appstatus3`;
ALTER TABLE `main_requisition` ADD COLUMN `client_id` int(11) AFTER `recruiters`;
ALTER TABLE `main_requisition_summary` ADD COLUMN `recruiters` varchar(150) AFTER `appstatus3`;
ALTER TABLE `main_requisition_summary` ADD COLUMN `client_id` INT(11) AFTER `recruiters`;
ALTER TABLE `main_candidatedetails` CHANGE `qualification` `qualification` VARCHAR(100) CHARSET utf8 COLLATE utf8_general_ci NULL;

INSERT  INTO `main_menu`(`id`,`menuName`,`url`,`helpText`,`toolTip`,`iconPath`,	`parent`,`menuOrder`,`nav_ids`,`isactive`,`modulename`,`segment_flag`,`org_menuid`,`menufields`,`menuQuery`,`hasJoins`,`modelName`,`functionName`,`defaultOrderBy`)VALUES
(207,'Contacts','/#','','','',3,8,',3,207',1,'default',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(208,'Clients','/clients','','','',207,3,',3,207,208',1,'default',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(209,'Projects','/projects','','','',207,4,',3,207,209',1,'default',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);


INSERT  INTO `main_privileges`(`role`,`group_id`,`object`,`addpermission`,`editpermission`,`deletepermission`,`viewpermission`,`uploadattachments`,`viewattachments`,`createdby`,`modifiedby`,`createddate`,`modifieddate`,`isactive`) VALUES
(1,NULL,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,1,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,2,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,3,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,4,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,5,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,6,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(2,1,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(3,2,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(4,3,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(5,4,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(6,5,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(8,6,207,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(1,NULL,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,1,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,2,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,3,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,4,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,5,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,6,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(2,1,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(3,2,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(4,3,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(5,4,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(6,5,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(8,6,208,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(1,NULL,187,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,1,187,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,3,187,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,6,187,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(2,1,187,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(4,3,187,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(8,6,187,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(1,NULL,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,1,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,2,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,3,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,4,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,5,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(NULL,6,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(2,1,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(3,2,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(4,3,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(5,4,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(6,5,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1),
(8,6,209,'Yes','Yes','Yes','Yes','Yes','Yes',1,1,NOW(),NOW(),1);


UPDATE `main_menu` SET `parent`=207 ,`nav_ids` =  ',3,207,21',`menuOrder`=1 WHERE id=21;
UPDATE `main_menu` SET `parent`=207 ,`nav_ids` =  ',3,207,187',`menuOrder`=2,`isactive`=1 WHERE id=187;
UPDATE `main_menu` SET `parent`=0 ,`isactive`=0 WHERE id=2;
UPDATE `main_menu` SET `parent`=3 ,`nav_ids` =  ',3,20,',`menuOrder`=2 WHERE id=20;
UPDATE `main_menu` SET `menuName`='Recruitments' WHERE id=19;
UPDATE `main_menu` SET menuName='Candidates' WHERE id=55;
UPDATE `main_menu` SET menuName='Interviews' WHERE id=57;
UPDATE `main_menu` SET `menuName`='External Users' WHERE `id`='21';
update `main_menu` set `menuName`='Manage Categories' where `id`='182';

DELIMITER $$

DROP TRIGGER `main_requisition_aft_ins`$$

CREATE
    TRIGGER `main_requisition_aft_ins` AFTER INSERT ON `main_requisition` 
    FOR EACH ROW BEGIN
        DECLARE pos_name,rep_name,bunit_name,dept_name,job_name,empt_name,app1_name,app2_name,app3_name,createdbyname VARCHAR(200);
        SELECT positionname INTO pos_name FROM main_positions WHERE id = new.position_id;
        SELECT userfullname INTO rep_name FROM main_users WHERE id = new.reporting_id;
        SELECT userfullname INTO app1_name FROM main_users WHERE id = new.approver1;
        SELECT userfullname INTO createdbyname FROM main_users WHERE id = new.createdby;
        SET app2_name = NULL;
        SET app3_name = NULL;
        IF new.approver2 IS NOT NULL THEN 
        SELECT userfullname INTO app2_name FROM main_users WHERE id = new.approver2;
        END IF;
        
        IF new.approver3 IS NOT NULL THEN 
        SELECT userfullname INTO app3_name FROM main_users WHERE id = new.approver3;
        END IF;
        SELECT unitname INTO bunit_name FROM main_businessunits WHERE id = new.businessunit_id;
        SELECT deptname INTO dept_name FROM main_departments WHERE id = new.department_id;
        SELECT jobtitlename INTO job_name FROM main_jobtitles WHERE id = new.jobtitle;
        SELECT te.employemnt_status INTO empt_name FROM main_employmentstatus em 
       INNER JOIN tbl_employmentstatus te ON te.id = em.workcodename WHERE em.id = new.emp_type;
		INSERT INTO main_requisition_summary 
        (req_id, requisition_code, onboard_date, position_id, position_name, reporting_id, reporting_manager_name,businessunit_id, businessunit_name, department_id, department_name, jobtitle, jobtitle_name,req_no_positions, selected_members, filled_positions, jobdescription, req_skills, req_qualification,req_exp_years,emp_type, emp_type_name, req_priority, additional_info, req_status, approver1, approver1_name,approver2, approver2_name, approver3, approver3_name, appstatus1, appstatus2, appstatus3,recruiters,client_id, isactive,createdby, modifiedby,createdon, modifiedon,createdby_name
        )
        VALUES
        (new.id, 
         
        new.requisition_code, 
        new.onboard_date, 
        new.position_id, 
        pos_name, 
        new.reporting_id, 
        rep_name, 
        new.businessunit_id, 
        bunit_name, 
        new.department_id, 
        dept_name, 
        new.jobtitle, 
        job_name, 
        new.req_no_positions, 
        new.selected_members, 
        new.filled_positions, 
        new.jobdescription, 
        new.req_skills, 
        new.req_qualification, 
        new.req_exp_years, 
        new.emp_type, 
        empt_name, 
        new.req_priority, 
        new.additional_info, 
        new.req_status, 
        new.approver1, 
        app1_name, 
        new.approver2, 
        app2_name, 
        new.approver3, 
        app3_name, 
        new.appstatus1, 
        new.appstatus2, 
        new.appstatus3, 
        new.recruiters,
        new.client_id,
        new.isactive, 
        new.createdby, 
        new.modifiedby, 
        new.createdon, 
        new.modifiedon,createdbyname
        );
    END;
$$

DELIMITER ;

DELIMITER $$
DROP TRIGGER `main_requisition_aft_upd`$$

CREATE TRIGGER `main_requisition_aft_upd` AFTER UPDATE ON `main_requisition` 
    FOR EACH ROW BEGIN
	DECLARE pos_name,rep_name,bunit_name,dept_name,job_name,empt_name,app1_name,app2_name,app3_name VARCHAR(200);
	SELECT positionname INTO pos_name FROM main_positions WHERE id = new.position_id;
	SELECT userfullname INTO rep_name FROM main_users WHERE id = new.reporting_id;
	SELECT userfullname INTO app1_name FROM main_users WHERE id = new.approver1;
	SET app2_name = NULL;
	SET app3_name = NULL;
	IF new.approver2 IS NOT NULL THEN 
        SELECT userfullname INTO app2_name FROM main_users WHERE id = new.approver2;
        END IF;
	
	IF new.approver3 IS NOT NULL THEN 
        SELECT userfullname INTO app3_name FROM main_users WHERE id = new.approver3;
        END IF;
	SELECT unitname INTO bunit_name FROM main_businessunits WHERE id = new.businessunit_id;
	SELECT deptname INTO dept_name FROM main_departments WHERE id = new.department_id;
	SELECT jobtitlename INTO job_name FROM main_jobtitles WHERE id = new.jobtitle;
	SELECT te.employemnt_status INTO empt_name FROM main_employmentstatus em 
       INNER JOIN tbl_employmentstatus te ON te.id = em.workcodename WHERE em.id = new.emp_type;
	UPDATE main_requisition_summary SET
	 requisition_code = new.requisition_code,onboard_date = new.onboard_date, position_id = new.position_id, position_name = pos_name, 
	 reporting_id = new.reporting_id, reporting_manager_name = rep_name , 
	businessunit_id = new.businessunit_id, businessunit_name = bunit_name, 
	department_id = new.department_id, department_name = dept_name, 
	jobtitle = new.jobtitle, jobtitle_name = job_name,	req_no_positions = new.req_no_positions, 
	selected_members = new.selected_members, filled_positions = new.filled_positions, 
	jobdescription = new.jobdescription, req_skills = new.req_skills, req_qualification = new.req_qualification, 
	req_exp_years = new.req_exp_years, 	emp_type = new.emp_type, emp_type_name = empt_name, 
	req_priority = new.req_priority, additional_info = new.additional_info, req_status = new.req_status,
	 approver1 = new.approver1, approver1_name = app1_name,	approver2 = new.approver2, 
	 approver2_name = app2_name, approver3 = new.approver3, approver3_name = app3_name, 
	 appstatus1 = new.appstatus1, appstatus2 = new.appstatus2, appstatus3 = new.appstatus3,recruiters=new.recruiters,client_id=new.client_id, 
	 modifiedby = new.modifiedby, 	modifiedon = new.modifiedon,isactive = new.isactive WHERE req_id = new.id ;
	 
    END;
$$

DELIMITER ;

UPDATE main_patches_version SET isactive=0;
INSERT INTO main_patches_version (version, createddate, modifieddate, isactive) VALUES ("3.1", now(), now(),1);